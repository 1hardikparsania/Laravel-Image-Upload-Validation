
<!DOCTYPE html>
<html>
 <head>
  <title>File Uploading in Laravel</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 </head>
 <body>
  <br />
  
  <div class="container">
   <h3 >Upload Image Validation Laravel</h3>
   <br />

   @if (count($errors) > 0)
    <div class="alert alert-danger">
     Upload Validation Error<br><br>
     <ul>
      @foreach ($errors->all() as $error)
       <li>{{ $error }}</li>
      @endforeach
     </ul>
    </div>
   @endif
   @if ($message = Session::get('success'))
   <div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">×</button>
           <strong>{{ $message }}</strong>
   </div>
   <img src="/images/{{ Session::get('path') }}" width="300" />
   @endif
 
    <form method="POST" action="/uploadsql" enctype="multipart/form-data">
    @csrf
 
        <div class="form-group">
 
            <label class="lable" for="name">Car Name </label>
 
            <div class="control">
 
                <input type="text" class="form-control" name="imagename" placeholder="Title" value="" required>
        
            </div>
       
        </div>
    
        <div class="form-group">
 
            <div class="control">
                 <input type="file" class="form-control" name="fileToUpload" aria-describedby="fileHelp">
            </div>
         </div>   
       
        <div class="form-group">
 
            <div class="control">
 
                <button type="submit" class="btn btn-primary">Upload Car</button>
 
            </div>
 
        </div>
 
    </form> 

    </body>
</html>   
 